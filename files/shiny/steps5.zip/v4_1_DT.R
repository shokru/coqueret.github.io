if(!require(shiny)){install.packages(c("shiny", "shinydashboard"))}
library(tidyverse)
library(shiny)
library(shinydashboard)

load("olympics.RData")

ui <- dashboardPage(
    dashboardHeader(title = "Olympic Medals"),                   # Title of the dashboard
    dashboardSidebar( 
        column(12, h2(" Inputs")),                               # Element 1: a simple title
        sliderInput("years", h4("Years"),                        # Element 2: year selection
                    min = 1895, max = 2015, 
                    value = c(1895, 2015), step = 5, sep = ""),
        checkboxGroupInput("season", h4("Season"),               # Element 3: season selection
                           choices = list("Summer" = "Summer", 
                                          "Winter" = "Winter"),
                           selected = c("Summer", "Winter")),
        checkboxGroupInput("gender", h4("Gender"),               # Element 4: gender selection
                           choices = list("Women" = "Women", 
                                          "Men" = "Men"),
                           selected = c("Women", "Men")),
        numericInput("max_country", h4("Max number countries"),  # Element 5: nb of countries displayed
                     min = 2, max = 12, step = 1, value = 6)),
    dashboardBody(
        DT::dataTableOutput("pt")
    )
)

server <- function(input, output){
    data <- reactive({                # Creates the dynamic data
        olympics %>%                  # Filter years, seasons & gender
            filter(Year >= input$years[1], 
                   Year <= input$years[2],
                   Season %in% input$season,
                   Gender %in% input$gender) 
    })
    
    filter_country <- reactive({      # Performs a filter to limit countries
        tmp <- data() %>% 
            group_by(Country) %>%           # Analysis by country
            summarise(nb_medals = n()) %>%  # Sum number of medals
            arrange(desc(nb_medals)) %>%    # Order
            head(input$max_country)         # Keep only max_country
    }) 
    
    # NEW ELEMENTS BELOW
    output$pt <- DT::renderDataTable({data()}, 
                                     options = list(   
                                         lengthMenu = list(c(5, 12, 19), c('5 lines', '12 rows', '19 items')),   
                                         pageLength = 5  
    ))
    
}

# Run the app ----
shinyApp(ui = ui, server = server)