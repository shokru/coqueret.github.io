library(tidyverse)
library(shiny)
library(shinydashboard)

load("olympics.RData")

ui <- dashboardPage(
    dashboardHeader(title = "Olympic Medals"),                   # Title of the dashboard
    dashboardSidebar( 
        column(12, h2(" Inputs")),                               # Element 1: a simple title
        sliderInput("years", h4("Years"),                        # Element 2: year selection
                    min = 1895, max = 2015, 
                    value = c(1895, 2015), step = 5, sep = ""),
        checkboxGroupInput("season", h4("Season"),               # Element 3: season selection
                           choices = list("Summer" = "Summer", 
                                          "Winter" = "Winter"),
                           selected = c("Summer", "Winter")),
        checkboxGroupInput("gender", h4("Gender"),               # Element 4: gender selection
                           choices = list("Women" = "Women", 
                                          "Men" = "Men"),
                           selected = c("Women", "Men")),
        numericInput("max_country", h4("Max number countries"),  # Element 5: nb of countries displayed
                     min = 2, max = 12, step = 1, value = 6
                     )
        ),
    
    ####### NEW ELEMENTS BELOW
    dashboardBody(
        fluidRow(
            align = "center",
            img(src = 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Olympic_rings_without_rims.svg/1200px-Olympic_rings_without_rims.svg.png', 
                align = "center", height="60%", width="60%")
        ),
        plotOutput("plot", height = 300),
        img(src = 'olympic_rings.jpg', width = "50%")
        )
)

server <- function(input, output){
    data <- reactive({                # Creates the dynamic data
        olympics %>%                  # Filter years, seasons & gender
            filter(Year >= input$years[1], 
                   Year <= input$years[2],
                   Season %in% input$season,
                   Gender %in% input$gender) 
    })
    
    filter_country <- reactive({      # Performs a filter to limit countries
        tmp <- data() %>% 
            group_by(Country) %>%           # Analysis by country
            summarise(nb_medals = n()) %>%  # Sum number of medals
            arrange(desc(nb_medals)) %>%    # Order
            head(input$max_country)         # Keep only max_country
    }) 
    
    ####### NEW ELEMENTS BELOW !!!!!
    output$plot <- renderPlot({
        olympics <- data() %>% filter(Country %in% filter_country()$Country)
        olympics %>% ggplot(aes(x = Year, fill = Country)) + geom_bar(width = 1.4) + 
            theme_minimal()
    })
    
}

# Run the app ----
shinyApp(ui = ui, server = server)