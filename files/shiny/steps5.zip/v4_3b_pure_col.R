if(!require(shiny)){install.packages(c("shiny", "shinydashboard"))}
library(tidyverse)
library(shiny)
library(shinydashboard)

load("olympics.RData")

ui <- dashboardPage(skin = "green",
                    dashboardHeader(title = "Olympic Medals"),                   # Title of the dashboard
                    dashboardSidebar( 
                        column(12, h2(" Inputs")),                               # Element 1: a simple title
                        sliderInput("years", h4("Years"),                        # Element 2: year selection
                                    min = 1895, max = 2015, 
                                    value = c(1895, 2015), step = 5, sep = ""),
                        ###### NEW ELEMENTS HERE
                        numericInput("max_country", h4("Max number countries"),  # Element 5: nb of countries displayed
                                     min = 2, max = 12, step = 1, value = 6)),
                    
                    ###### NEW ELEMENTS HERE
                    dashboardBody(
                        fluidRow(
                            column(8, 
                                   DT::dataTableOutput("pt"),
                                   plotOutput("graph")
                            ),
                            column(4,
                                   valueBoxOutput("box3", width = 12),
                                   infoBoxOutput("box4", width = 12),
                                   valueBoxOutput("box1", width = 12),
                                   infoBoxOutput("box2", width = 12)
                            )
                        )
                    )
)

server <- function(input, output){
    data <- reactive({                # Creates the dynamic data
        olympics %>%                  # Filter years, seasons & gender
            filter(Year >= input$years[1], 
                   Year <= input$years[2]) 
    })
    
    filter_country <- reactive({      # Performs a filter to limit countries
        tmp <- data() %>% 
            group_by(Country) %>%           # Analysis by country
            summarise(nb_medals = n()) %>%  # Sum number of medals
            arrange(desc(nb_medals)) %>%    # Order
            head(input$max_country)         # Keep only max_country
    }) 
    
    output$box1 <- renderValueBox({
        olympics <- data()
        valueBox(
            value = sum(olympics$Medal=="Gold"), 
            subtitle =  "Gold", 
            icon = icon("medal", lib = "font-awesome"),
            color = "yellow"
        )
    })
    
    output$box2 <- renderInfoBox({
        olympics <- data()
        infoBox(
            value = sum(olympics$Medal=="Silver"),
            title = "Silver", 
            icon = icon("medal", lib = "font-awesome"),
            color = "olive"
        )
    })
    
    output$box3 <- renderValueBox({
        olympics <- data()
        valueBox(
            value = sum(olympics$Medal=="Bronze"), 
            subtitle =  "Bronze", 
            icon = icon("medal", lib = "font-awesome"),
            color = "maroon"
        )
    })
    
    output$box4 <- renderInfoBox({
        olympics <- data()
        infoBox(
            value = sum(olympics$Country=="USA"),
            title = "USA", 
            icon = icon("flag-usa", lib = "font-awesome"),
            color = "blue"
        )
    })
    
    output$pt <- DT::renderDataTable({data() %>% select(c(1,2,4,5,6))}, 
                                     options = list(   
                                         lengthMenu = list(c(5, 12, 19), c('5 lines', '12 rows', '19 items')),   
                                         pageLength = 3  
                                     ))
    
    output$graph <- renderPlot({
        data() %>%
            group_by(City) %>%
            summarise(nb_med = n()) %>%
            arrange(desc(nb_med)) %>%
            head(10) %>%
            ggplot(aes(x = nb_med, y = reorder(City, nb_med))) + geom_col() + theme_light()
    })
    
}

# Run the app ----
shinyApp(ui = ui, server = server)