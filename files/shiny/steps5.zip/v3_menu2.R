if(!require(shiny)){install.packages(c("shiny", "shinydashboard"))}
library(tidyverse)
library(shiny)
library(shinydashboard)
library(viridis)

load("olympics.RData")

ui <- dashboardPage(
    dashboardHeader(title = "Olympic Medals"),                   # Title of the dashboard
    dashboardSidebar( 
        sidebarMenu(
            ###### NEW ELEMENTS BELOW !!!
            menuItem("Plot", tabName = "plot", icon = icon("image", lib = "font-awesome")),
            menuItem("Table", tabName = "table", icon = icon("table", lib = "font-awesome")),
            menuItem("Inputs", tabName = "inputvalues", icon = icon("keyboard", lib = "font-awesome"),
                     sliderInput("years", h4("Years"),                        # Widget 1: year selection
                                 min = 1895, max = 2015, 
                                 value = c(1895, 2015), step = 5, sep = ""),
                     checkboxGroupInput("season", h4("Season"),               # Widget 2: season selection
                                        choices = list("Summer" = "Summer", 
                                                       "Winter" = "Winter"),
                                        selected = c("Summer", "Winter")),
                     checkboxGroupInput("gender", h4("Gender"),               # Widget 3: gender selection
                                        choices = list("Women" = "Women", 
                                                       "Men" = "Men"),
                                        selected = c("Women", "Men")),
                     numericInput("max_country", h4("Max number countries"),  # Widget 4: nb of countries displayed
                                  min = 2, max = 12, step = 1, value = 6)
            )
        )
        
    ),
    dashboardBody(
        ####### NEW ELEMENTS BELOW !!!!!
        tabItems(
            tabItem(tabName ="plot", 
                    plotOutput("plot", height = 300)
            ),
            tabItem(tabName ="table", 
                    DT::dataTableOutput("pt")
            )
        )
        
    )
)

server <- function(input, output){
    data <- reactive({                # Creates the dynamic data
        olympics %>%                  # Filter years, seasons & gender
            filter(Year >= input$years[1], 
                   Year <= input$years[2],
                   Season %in% input$season,
                   Gender %in% input$gender) 
    })
    
    filter_country <- reactive({      # Performs a filter to limit countries
        tmp <- data() %>% 
            group_by(Country) %>%           # Analysis by country
            summarise(nb_medals = n()) %>%  # Sum number of medals
            arrange(desc(nb_medals)) %>%    # Order
            head(input$max_country)         # Keep only max_country
    }) 
    
    output$pt <- DT::renderDataTable({data()})
    output$plot <- renderPlot({
        olympics <- data() %>% filter(Country %in% filter_country()$Country)
        olympics %>% 
            group_by(Athlete, Country) %>%
            count() %>%
            filter(n > 10) %>%
            ggplot(aes(x = reorder(Athlete,n), y = n, fill = Country)) + geom_col() +
            coord_flip() + xlab("Athlete") +
            scale_fill_viridis(discrete = TRUE)
    }, height = 300)
    
    output$text <- renderText("Choose parameters")
}

# Run the app ----
shinyApp(ui = ui, server = server)