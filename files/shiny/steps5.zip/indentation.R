library(tidyverse)
library(shiny)
library(shinydashboard)
library(DT)

load("olympics.RData")

ui <- dashboardPage(
    dashboardHeader(title = "Olympic Medals"),                  
dashboardSidebar( 
    sliderInput("years", h4("Years"),                       
                    min = 1895, max = 2015, 
         value = c(1895, 2015), step = 5, sep = ""
         ),
 checkboxGroupInput("season", h4("Season"),               
                           choices = list("Summer" = "Summer", 
                                          "Winter" = "Winter"),
                  selected = c("Summer", "Winter")
                  ),
    checkboxGroupInput("gender", h4("Gender"),              
                   choices = list("Women" = "Women", 
                                          "Men" = "Men"),
                   selected = c("Women", "Men")
                   ),
        numericInput("max_country", h4("Max number countries"), 
       min = 2, max = 12, step = 1, value = 6)
),
    
    dashboardBody(
 plotOutput("plot", height = 300),
        DT::dataTableOutput("pt")
    )
)

server <- function(input, output){
    data <- reactive({                # Creates the dynamic data
        olympics %>%                  # Filter years, seasons & gender
            filter(Year >= input$years[1], 
                   Year <= input$years[2],
                   Season %in% input$season,
                   Gender %in% input$gender) 
    })
    
    ####### NEW ELEMENTS BELOW !!!!!
    filter_country <- reactive({            # Performs a filter to limit countries
        data() %>% 
            group_by(Country) %>%           # Analysis by country
            summarise(nb_medals = n()) %>%  # Sum number of medals
            arrange(desc(nb_medals)) %>%    # Order
            head(input$max_country)         # Keep only max_country
    }) 
    
    output$pt <- DT::renderDataTable({data()})
    output$plot <- renderPlot({
        data() %>% filter(Country %in% filter_country()$Country) %>%
                   ggplot(aes(x = Year, fill = Country)) + geom_bar(width = 1.4)
    }, height = 300)
    
    
}

# Run the app ----
shinyApp(ui = ui, server = server)