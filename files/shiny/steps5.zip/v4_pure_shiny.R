if(!require(shiny)){install.packages(c("shiny", "shinydashboard"))}
library(tidyverse)
library(shiny)
library(plotly)
library(shinydashboard)

load("olympics.RData")

ui <- fluidPage( 
    fluidRow(box(h3(textOutput("text")), width = 12)),
    fluidRow(
        column(4, sliderInput("years", h4("Years"),                        # Element 2: year selection
                              min = 1895, max = 2015, 
                              value = c(1895, 2015), step = 5, sep = "")
        ),
        column(4, selectizeInput("sport", "Sport", 
                                 choices = unique(olympics$Sport),
                                 selected = "Athletics"),
        ),
        column(4,checkboxGroupInput("gender", h4("Gender"),               # Element 4: gender selection
                                    choices = list("Women" = "Women", 
                                                   "Men" = "Men"),
                                    selected = c("Women", "Men"))
        )
    ),
    
    ###### NEW ELEMENTS HERE
    fluidRow(
        column(6, plotlyOutput("g1")),
        column(6, DT::dataTableOutput("t0"))
    )
    
)

server <- function(input, output){
    data <- reactive({                # Creates the dynamic data
        olympics %>%                  # Filter years, seasons & gender
            filter(Year >= input$years[1], 
                   Year <= input$years[2],
                   Sport %in% input$sport,
                   Gender %in% input$gender) 
    })
    ###### NEW ELEMENTS HERE
    output$g1 <- renderPlotly({
        g <- data() %>%
            group_by(Year, Discipline) %>%
            count() %>% 
            ggplot(aes(x = Year, y = n, color = Discipline)) + geom_line() + 
            geom_point() + 
            theme_minimal() 
        ggplotly(g) %>% layout(legend = list(orientation = "h", x = 0.4, y = -0.2))
    })
    output$t0 <- DT::renderDataTable(data() %>% select(Year, City, Athlete, Medal),
                                     rownames = FALSE)
    output$text <- renderText("Hi, this is my app. It's about olympic medals.")
}

# Run the app ----
shinyApp(ui = ui, server = server)