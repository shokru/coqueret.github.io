if(!require(thematic)){install.packages(c("thematic"))}
library(tidyverse)
library(shiny)
library(plotly)
library(thematic)

thematic_shiny(font = "auto")

load("olympics.RData")

ui <- fluidPage(
    theme = bslib::bs_theme(
        bg = "#002B36", fg = "#EEE8D5", primary = "#2AA198",
        # bslib also makes it easy to import CSS fonts
        base_font = bslib::font_google("Festive") # Pacifico 
        # Other fonts: https://rstudio.github.io/bslib/reference/font_face.html
        # and: https://fonts.google.com
    ),
    fluidRow(
        column(4, sliderInput("years", h4("Years"),                        # Element 2: year selection
                                   min = 1895, max = 2015, 
                                   value = c(1895, 2015), step = 5, sep = "")),
        column(4, checkboxGroupInput("season", h4("Season"),               # Element 3: season selection
                                     choices = list("Summer" = "Summer", 
                                                    "Winter" = "Winter"),
                                     selected = c("Summer", "Winter"))),
        column(4, checkboxGroupInput("gender", h4("Gender"),               # Element 4: gender selection
                                     choices = list("Women" = "Women", 
                                                    "Men" = "Men"),
                                     selected = c("Women", "Men")))
        ),

        plotOutput("plot")
)

server <- function(input, output){
    data <- reactive({                # Creates the dynamic data
        olympics %>%                  # Filter years, seasons & gender
            filter(Year >= input$years[1], 
                   Year <= input$years[2],
                   Season %in% input$season,
                   Gender %in% input$gender) 
    })
    
    # NEW ELEMENTS BELOW
    output$plot <- renderPlot({
        data() %>%
            group_by(Year) %>%
            summarise(prop_women = mean(Gender == "Women")) %>%
            mutate(level = if_else(prop_women < 0.3, "Low", 
                                   if_else(prop_women > 0.4, "High", "Medium"))) %>%
            ggplot(aes(x = Year, y = prop_women, fill = level)) + geom_col() 
    })
    
}

# Run the app ----
shinyApp(ui = ui, server = server)