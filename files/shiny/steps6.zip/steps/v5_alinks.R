if(!require(shinyjs)){install.packages(c("shinyjs", "shinyalert"))}
library(tidyverse)
library(shiny)
library(shinydashboard)
library(DT)
library(gapminder)
library(shinyjs)
library(shinyalert)


ui <- dashboardPage(
    dashboardHeader(title = "Test",
                    tags$li(class = "dropdown",
                            tags$a(href="http://www.linkedin.com/in/guillaumecoqueret/", 
                                   target="_blank", 
                                   icon("linkedin", "fa-1x", lib = "font-awesome")  # fa-3x mean 3 times bigger
                            )
                    ),
                    tags$li(class = "dropdown",
                            tags$a(href="http://www.twitter.com/g_coqueret", 
                                   target="_blank", 
                                   icon("twitter", "fa-1x", lib = "font-awesome")  # fa-3x mean 3 times bigger
                            )
                    ),
                    tags$li(class = "dropdown",
                            tags$a(href="https://github.com/shokru", 
                                   target="_blank", 
                                   icon("github", "fa-1x", lib = "font-awesome")  # fa-3x mean 3 times bigger
                            )
                    )#,
                    #tags$li(class = "dropdown", column(12))
    ),           
    dashboardSidebar(),
    dashboardBody()
)

server <- function(input, output){
    
    
    
    
}

# Run the app ----
shinyApp(ui = ui, server = server)