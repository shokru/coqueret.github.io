if(!require(shiny)){install.packages(c("shiny", "shinydashboard"))}
library(tidyverse)
library(shiny)
library(shinydashboard)
library(plotly)

load("olympics.RData")

ui <- dashboardPage(
    dashboardHeader(title = "Olympic Medals"),                   # Title of the dashboard
    dashboardSidebar( 
        column(12, h2(" Inputs")),                               # Element 1: a simple title
        sliderInput("years", h4("Years"),                        # Element 2: year selection
                    min = 1895, max = 2015, 
                    value = c(1895, 2015), step = 5, sep = ""),
        checkboxGroupInput("season", h4("Season"),               # Element 3: season selection
                           choices = list("Summer" = "Summer", 
                                          "Winter" = "Winter"),
                           selected = c("Summer", "Winter")),
        checkboxGroupInput("gender", h4("Gender"),               # Element 4: gender selection
                           choices = list("Women" = "Women", 
                                          "Men" = "Men"),
                           selected = c("Women", "Men")),
        radioButtons("color", h4("Color of line"),               # Element 4: gender selection
                           choices = list("green" = "#009933", 
                                          "blue" = "blue",
                                          "red" = "red"),
                           selected = "blue")
    ),
    
    dashboardBody(
        ###### NEW ELEMENTS HERE
        fluidRow(column(12, box(radioButtons("show", "Analysis displayed", inline = T,
                                         c("Oustanding athletes" = "athletes",
                                           "Gender gap" = "gender_gap")), width = 12)
                        )
                 ),
        conditionalPanel(
            condition = "input.show == 'gender_gap'", # Mind the syntax which is strange...
            plotlyOutput("plot")
        ),
        conditionalPanel(
            condition = "input.show == 'athletes'", # Mind the syntax which is strange...
            DT::dataTableOutput("pt")
        )
    )
)

server <- function(input, output){
    data <- reactive({                # Creates the dynamic data
        olympics %>%                  # Filter years, seasons & gender
            filter(Year >= input$years[1], 
                   Year <= input$years[2],
                   Season %in% input$season,
                   Gender %in% input$gender) 
    })

    
    ###### NEW ELEMENTS HERE
    output$plot <- renderPlotly({
        g <- data() %>% 
            group_by(Year) %>%
            summarise(prop_women = mean(Gender == "Women")) %>%
            ggplot(aes(x = Year, y = prop_women)) + 
            theme_minimal() + 
            geom_line(color = input$color) + 
            geom_point(color = input$color) 
        ggplotly(g)
    })
    
    output$pt <- DT::renderDataTable({
        data() %>% 
            group_by(Athlete, Country, Sport) %>% # Adding country and sport for display: does not change output
            summarise(nb_medals = n()) %>%
            arrange(desc(nb_medals))
        }, 
        options = list(   
                  lengthMenu = list(c(5, 10), c('5', '10')),   
                  pageLength = 5  
                )
        )
    
}

# Run the app ----
shinyApp(ui = ui, server = server)