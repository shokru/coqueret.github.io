if(!require(timevis)){install.packages("timevis")}
library(tidyverse)
library(shiny)
library(plotly)
library(timevis)
library(lubridate)
library(stringi)
library(ggthemes)
library(shinyWidgets)
load("olympics.RData")

ui <- fluidPage(
    titlePanel("A pure Shiny app!"),
    tags$head(tags$link(href = "style.css", rel = "stylesheet")),
    tags$div(tags$br()),             # Skip a line/row
    fluidRow(align = "center", 
             textOutput("welcome"),
             tags$a(href="http://www.linkedin.com/in/guillaumecoqueret/", 
                    target="_blank", 
                    icon("linkedin", "fa-2x", lib = "font-awesome")  # fa-3x mean 3 times bigger
             ), 
             tags$a(href="http://www.twitter.com/g_coqueret", 
                    target="_blank", 
                    icon("twitter", "fa-2x", lib = "font-awesome")  # fa-3x mean 3 times bigger
             ),
             tags$a(href="https://github.com/shokru", 
                    target="_blank", 
                    icon("github", "fa-2x", lib = "font-awesome")  # fa-3x mean 3 times bigger
             )
    ),
    
    
    tags$div(tags$br()),             # Skip a line/row
    fluidRow(
        column(3,
               fluidRow(
                   align = "center",
                   img(src = 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Olympic_rings_without_rims.svg/1200px-Olympic_rings_without_rims.svg.png', 
                       align = "center", height="42%", width="42%")
               ),
               h6(span(textOutput("explain"), style="color:grey")),
               sliderInput("years", h4("Years"),                        
                           min = 1895, max = 2015, 
                           value = c(1895, 2015), step = 5, sep = ""
               ),
               
               checkboxGroupButtons(
                   inputId = "season", label = "Season", 
                   choices = c("Summer", "Winter"), 
                   justified = TRUE, status = "primary", selected = c("Summer", "Winter"),
                   checkIcon = list(yes = icon("ok", lib = "glyphicon"), no = icon("remove", lib = "glyphicon"))
               ),
               
               checkboxGroupButtons(
                   inputId = "gender", label = "Gender", 
                   choices = c("Men", "Women"), 
                   justified = TRUE, status = "primary", selected = c("Men", "Women"),
                   checkIcon = list(yes = icon("ok", lib = "glyphicon"), no = icon("remove", lib = "glyphicon"))
               )
               
        ),
        column(9,
               navbarPage("Content", 
                          tabPanel("Cities", plotlyOutput("plotly", height = "510px")),
                          tabPanel("Best Athletes", timevisOutput("time")),
                          tabPanel("Custom Plot",
                                   fluidRow(
                                       selectInput(
                                           "yaxis",
                                           "Select variable for Y axis",
                                           choices = colnames(olympics)[2:9],
                                           selected = colnames(olympics)[3]
                                       ),
                                       plotlyOutput("custplot")
                                   ))
               )
               
        )
    )
    
)

server <- function(input, output){
    data <- reactive({                # Creates the dynamic data
        olympics %>%                  # Filter years, seasons & gender
            filter(Year >= input$years[1], 
                   Year <= input$years[2],
                   Season %in% input$season,
                   Gender %in% input$gender) 
    })
    
    output$welcome <- renderText("Welcome to this pure Shiny app.")
    output$plotly <- renderPlotly({
        g <- data() %>%
            group_by(City) %>%
            summarize(nb_medals = n(),
                      nb_games = as.factor(length(unique(Year)))) %>%
            ggplot(aes(x = nb_medals, y = reorder(City, nb_medals), fill = nb_games)) +
            geom_col() + xlab("Number of medals") + ylab("City") + 
            ggtitle("Medals & Games per City") + theme(legend.position = c(0.2,0.7)) +
            theme_light() + scale_fill_manual(values = c("#FFA728", "#92C2DF", "#73A88D"))
        ggplotly(g) %>% 
            layout(
                legend = list(
                    orientation = "h",
                    x = 0.5,
                    y = 0.5
                )
            ) 
    })
    
    output$time <- renderTimevis({
        temp <- data() %>%
            group_by(Athlete, Year) %>%
            summarize(n = n()) %>%
            na.omit() %>%
            group_by(Year) %>%
            mutate(max = max(n)) %>%
            ungroup() %>%
            filter(n == max) %>%
            separate(Athlete, into = c("Name", "Surname"), sep = ",")
        temp %>% 
            mutate(id = row_number(),
                   content = paste(iconv(Name, to="ASCII//TRANSLIT"), "(",n, ")"),
                   start = as.character(make_date(year = Year, month = 7, day = 15)),
                   end = NA) %>%
            select(id, content, start, end) %>%
            timevis(zoomFactor = 0.5)
        # ggplot(aes(x = Year, y = n)) + geom_point() + 
        # geom_text(aes(label = Name), angle = 15, check_overlap = TRUE, vjust = 0, nudge_y = 0.1) +
        # theme_light() + theme(text = element_text(size = 16)) + ylab("Number of medals") +
        # ggtitle("Best athletes in games")
    })
    
    output$custplot <- renderPlotly({
        g <- data() %>%
            #mutate(var = input$yaxis) %>%
            group_by_(input$yaxis) %>%
            count(sort = T) %>%
            arrange(desc(n)) %>%
            na.omit() %>%
            head(20) %>%
            ggplot(aes_string(x = "n", y = paste0("reorder(",as.character(input$yaxis),", n)") )) + # this is quite technical
            geom_col(fill = "#A4B9C2",  alpha = 0.5) +
            ylab(as.character(input$yaxis)) + theme_light()
        
        ggplotly(g)
    })
    
    output$explain <- renderText("This dashboard provides some analyses on Olympic Games between 1896 and 2012. Two graphs are provided: one on cities and one on athletes. The basline results are for all games but they can be restricted via the selection tools below.")
}



# Run the app ----
shinyApp(ui = ui, server = server)