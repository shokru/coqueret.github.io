library(tidyverse)
library(shiny)
library(shinydashboard)
library(DT)
library(gapminder)
library(shinyjs)
library(shinyalert)

# see also updateSelectInput: https://shiny.rstudio.com/reference/shiny/1.2.0/updateSelectInput.html

data("gapminder")

ui <- dashboardPage(
    dashboardHeader(title = "Gapminder"),                        # Title of the dashboard
    dashboardSidebar( 
        sliderInput("years", h4("Years"),                        # Element 1: year selection
                    min = 1950, max = 2010, 
                    value = c(1895, 2015), step = 5, sep = ""),
        radioButtons("continent", h4("Continent"),               # Element 2: continent selection
                     choices = gapminder %>% pull(continent) %>% unique(),
                     selected = "Africa"
        ),
        # NEW ELEMENT BELOW
        uiOutput("select")                                       # Element 3: country selection
    ),
    dashboardBody(
        DT::dataTableOutput("table")
    )
)

server <- function(input, output){
    # NEW ELEMENTS BELOW
    choices_for_country_list <- reactive({
        gapminder %>% 
            filter(continent == input$continent) %>% 
            pull(country) %>% 
            unique()         # pull() extracts one particular variable from a dataframe
     }) 
    
    output$select <- renderUI(
        selectizeInput("country", "Country", 
                    choices = choices_for_country_list(),
                    multiple = TRUE)
    )
    
    data <- reactive({                       # Creates the dynamic data
        gapminder %>%                        # Filter years & country
            filter(year >= input$years[1],
                   year <= input$years[2],
                   country %in% input$country) %>%
            arrange(year)
    })
    
    output$table <- DT::renderDataTable({data()})
    
    
}

# Run the app ----
shinyApp(ui = ui, server = server)