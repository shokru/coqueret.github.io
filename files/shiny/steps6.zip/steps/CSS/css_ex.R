if(!require(shiny)){install.packages(c("shiny", "shinydashboard"))}
library(tidyverse)
library(shiny)
library(shinydashboard)
library(dashboardthemes)

# Inspired from: https://github.com/nik01010/dashboardthemes

source("theme.R")


ui <- dashboardPage(
    dashboardHeader(title = "Olympic Medals"),                   # Title of the dashboard
    dashboardSidebar(),
    
    ###### NEW ELEMENTS HERE
    dashboardBody(
        customTheme,
        h1(textOutput("text")))
)

server <- function(input, output){
    output$text <- renderText("HAHA Lorem Ipsum, this is the Avenir Font.")
    
}

# Run the app ----
shinyApp(ui = ui, server = server)