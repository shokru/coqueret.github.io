if(!require(bslib)){install.packages("bslib")}

library(bslib) 
library(tidyverse)
library(shiny)

my_theme <- bs_theme(   # Where you define your style
    bg = "#202123", fg = "#B8BCC2", primary = "#EA80FC", 
    base_font = font_google("Grandstander"),
    "font-size-base" = "1.1rem"
)



load("olympics.RData")

ui <- fluidPage(    # FULL PAGE!
    theme = my_theme,
    column(3,
           sliderInput("years", h4("Years"),                        # Element 1: year selection
                       min = 1950, max = 2015,                      
                       value = c(1950, 2015), step = 5, sep = ""
           ),                                           # Mind the comma! Separation with next widget
           checkboxGroupInput("season", h4("Season"),               # Element 2: season selection
                              choices = list("Summer" = "Summer", 
                                             "Winter" = "Winter"),
                              selected = c("Summer", "Winter")
           )
    ),
    column(9, plotOutput("plot"))
    
)

server <- function(input, output){ # Empty
    
    data <- reactive({                # Creates the dynamic data
        olympics %>%                  # Filter years, seasons & gender
            filter(Year >= input$years[1], 
                   Year <= input$years[2],
                   Season %in% input$season) 
    })
    
    output$plot <- renderPlot(data() %>%
                                  group_by(Country, Year, Medal) %>%
                                  summarise(nb_medal = n()) %>%
                                  group_by(Country) %>%
                                  mutate(sum_med = sum(nb_medal)) %>%
                                  ungroup() %>%
                                  mutate(rank_med = dense_rank(desc(sum_med))) %>%
                                  filter(rank_med < 11) %>%
                                  ggplot(aes(x = Country, y = nb_medal, color = Medal)) + geom_jitter() + theme_dark() +
                                  scale_color_manual(values = c("#E88A02", "#FFDE26", "#B9BABA")) +
                                  ylab("Medals per olympiad") + 
                                  theme(plot.background = element_rect(fill = "#999999"),
                                        panel.background = element_rect(fill = "#222222"))
    )
}

# Run the app ----
shinyApp(ui = ui, server = server)