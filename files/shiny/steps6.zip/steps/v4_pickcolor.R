library(tidyverse)
library(shiny)
library(shinydashboard)
library(DT)
library(gapminder)

if(!require(colourpicker)){install.packages("colourpicker")} # New packages
if(!require(remotes)){install.packages("remotes")}
library(colourpicker)

gapminder <- gapminder

ui <- dashboardPage(
    dashboardHeader(title = "Gapminder"),             # Title of the dashboard
    dashboardSidebar( 
        sliderInput("years", h4("Years"),                        # Element 1: year selection
                    min = 1950, max = 2010, 
                    value = c(1895, 2015), step = 5, sep = ""),
        colourpicker::colourInput("col", "Select colour", "purple")
        
    ),
    dashboardBody(
        plotOutput("plot"),
        DT::dataTableOutput("table")
    )

)

server <- function(input, output){
    data <- reactive({                # Creates the dynamic data
            gapminder %>%                  # Filter years, seasons & gender
                filter(year >= input$years[1],
                       year <= input$years[2])
    })
    
    output$table <- DT::renderDataTable({data()})
    output$plot <- renderPlot({
        data() %>%
            group_by(year) %>%
            summarize(avg_lifeexp = mean(lifeExp)) %>%
            ggplot(aes(x = year, y = avg_lifeexp)) + geom_col(fill = input$col) +
            theme_minimal() + 
            coord_cartesian(ylim = c(40,70))
    })

    
}

# Run the app ----
shinyApp(ui = ui, server = server)