library(tidyverse)
library(shiny)
library(shinydashboard)
library(DT)
library(gapminder)

data("gapminder")

ui <- dashboardPage(
    dashboardHeader(title = "Gapminder"),                        # Title of the dashboard
    dashboardSidebar( 
        sliderInput("years", h4("Years"),                        # Element 1: year selection
                    min = 1950, max = 2010, 
                    value = c(1895, 2015), step = 5, sep = ""),
        radioButtons("continent", h4("Continent"),               # Element 2: season selection
                     choices = list("Africa" = "Africa",
                                    "Americas" = "Americas",
                                    "Asia" = "Asia",
                                    "Europe" = "Europe",
                                    "Oceania" = "Oceania"),
                     selected = c("Africa")
        ),
        conditionalPanel(
            condition = "input.continent == 'Africa'", # Mind the syntax which is strange...
            selectizeInput(                                   # This widget selects one particular country
                'country1', 'Select country',
                choices = gapminder %>%
                    filter(continent == "Africa") %>%
                    select(country) %>%
                    unlist() %>%
                    as.character() %>%
                    as.factor() %>%
                    levels()             # The levels of a factor are all possible values
            )   
        ),
        conditionalPanel(
            condition = "input.continent == 'Americas'", # Mind the syntax which is strange...
            selectizeInput(                                   # This widget selects one particular country
                'country2', 'Select country',
                choices = gapminder %>%
                    filter(continent == "Americas") %>%
                    select(country) %>%
                    unlist() %>%
                    as.character() %>%
                    as.factor() %>%      # The levels of a factor are all possible values
                    levels()   
            )
        ),
        conditionalPanel(
            condition = "input.continent == 'Asia'", # Mind the syntax which is strange...
            selectizeInput(                                   # This widget selects one particular country
                'country3', 'Select country',
                choices = gapminder %>%
                    filter(continent == "Asia") %>%
                    select(country) %>%
                    unlist() %>%
                    as.character() %>%
                    as.factor() %>%
                    levels()              # The levels of a factor are all possible values 
            )
        ),
        conditionalPanel(
            condition = "input.continent == 'Europe'", # Mind the syntax which is strange...
            selectizeInput(                                   # This widget selects one particular country
                'country4', 'Select country',
                choices = gapminder %>%
                    filter(continent == "Europe") %>%
                    select(country) %>%
                    unlist() %>%
                    as.character() %>%
                    as.factor() %>%
                    levels()              # The levels of a factor are all possible values 
            )
        ),
        conditionalPanel(
            condition = "input.continent == 'Oceania'", # Mind the syntax which is strange...
            selectizeInput(                                   # This widget selects one particular country
                'country5', 'Select country',
                choices = gapminder %>%
                    filter(continent == "Oceania") %>%
                    select(country) %>%
                    unlist() %>%
                    as.character() %>%
                    as.factor() %>%
                    levels()              # The levels of a factor are all possible values 
            )
        )
    ),
    dashboardBody(
        DT::dataTableOutput("table")
    )
)

server <- function(input, output){
    data <- reactive({                # Creates the dynamic data
        if(input$continent == "Africa"){
            tmp <- gapminder %>%                  # Filter years, seasons & gender
                filter(year >= input$years[1],
                       year <= input$years[2],
                       country %in% input$country1)}
        if(input$continent == "Americas"){
            tmp <- gapminder %>%                  # Filter years, seasons & gender
                filter(year >= input$years[1],
                       year <= input$years[2],
                       country %in% input$country2)}
        if(input$continent == "Asia"){
            tmp <- gapminder %>%                  # Filter years, seasons & gender
                filter(year >= input$years[1],
                       year <= input$years[2],
                       country %in% input$country3)}
        if(input$continent == "Europe"){
            tmp <- gapminder %>%                  # Filter years, seasons & gender
                filter(year >= input$years[1],
                       year <= input$years[2],
                       country %in% input$country4)}
        if(input$continent == "Oceania"){
            tmp <- gapminder %>%                  # Filter years, seasons & gender
                filter(year >= input$years[1],
                       year <= input$years[2],
                       country %in% input$country5)}
        return(tmp)
    })
    
    output$table <- DT::renderDataTable({data()})
    
    
}

# Run the app ----
shinyApp(ui = ui, server = server)