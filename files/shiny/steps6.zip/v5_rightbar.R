library(tidyverse)
library(shiny)
library(shinydashboard)
library(DT)
library(gapminder)

if(!require(shinydashboardPlus)){install.packages("shinydashboardPlus")}
library(shinydashboardPlus)

data("gapminder")

ui <- dashboardPagePlus(
    dashboardHeaderPlus(title = "Gapminder",
                        enable_rightsidebar = TRUE),             # Title of the dashboard
    dashboardSidebar( 
        sliderInput("years", h4("Years"),                        # Element 1: year selection
                    min = 1950, max = 2010, 
                    value = c(1895, 2015), step = 5, sep = "")
        
    ),
    dashboardBody(
        DT::dataTableOutput("table")
    ),
    rightSidebar(
        background = "dark",
        rightSidebarTabContent(id = 6,
                               title = "Tab 1",
                               icon = "desktop",
                               active = TRUE,
            radioButtons("continent", h4("Continent"),               # Element 2: season selection
                         choices = list("Africa" = "Africa",
                                        "Americas" = "Americas",
                                        "Asia" = "Asia",
                                        "Europe" = "Europe",
                                        "Oceania" = "Oceania"),
                         selected = c("Africa")
            )
        )
    ),
    title = "Right Sidebar"
)

server <- function(input, output){
    data <- reactive({                # Creates the dynamic data
            gapminder %>%                  # Filter years, seasons & gender
                filter(year >= input$years[1],
                       year <= input$years[2],
                       continent %in% input$continent)
    })
    
    output$table <- DT::renderDataTable({data()})
    
    
}

# Run the app ----
shinyApp(ui = ui, server = server)