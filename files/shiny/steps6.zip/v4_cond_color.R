if(!require(shiny)){install.packages(c("shiny", "shinydashboard"))}
library(tidyverse)
library(shiny)
library(shinydashboard)

load("olympics.RData")

ui <- dashboardPage(
    dashboardHeader(title = "Olympic Medals"),                   # Title of the dashboard
    dashboardSidebar( 
        column(12, h2(" Inputs")),                               # Element 1: a simple title
        sliderInput("years", h4("Years"),                        # Element 2: year selection
                    min = 1895, max = 2015, 
                    value = c(1895, 2015), step = 5, sep = ""),
        checkboxGroupInput("season", h4("Season"),               # Element 3: season selection
                           choices = list("Summer" = "Summer", 
                                          "Winter" = "Winter"),
                           selected = c("Summer", "Winter")),
        checkboxGroupInput("gender", h4("Gender"),               # Element 4: gender selection
                           choices = list("Women" = "Women", 
                                          "Men" = "Men"),
                           selected = c("Women", "Men")),
        numericInput("max_country", h4("Max number countries"),  # Element 5: nb of countries displayed
                     min = 2, max = 12, step = 1, value = 6)),
    
    ###### NEW ELEMENTS HERE
    dashboardBody(
        valueBoxOutput("box1")
    )
)

server <- function(input, output){
    data <- reactive({                # Creates the dynamic data
        olympics %>%                  # Filter years, seasons & gender
            filter(Year >= input$years[1], 
                   Year <= input$years[2],
                   Season %in% input$season,
                   Gender %in% input$gender) 
    })
    
    ###### NEW ELEMENTS HERE
    output$box1 <- renderValueBox({
        olympics <- data()
        prop <- round(mean(olympics$Gender=="Women"), 2)
        if(prop < 0.3){colorbox <- "red"}
        if(prop > 0.4){colorbox <- "green"}
        if(prop >= 0.3 & prop <= 0.4){colorbox <- "yellow"}
        valueBox(
            value = prop, 
            subtitle =  "Proportion of women",
            icon = icon("female", lib = "font-awesome"),
            color = colorbox,
            width = 4  # Width in Bootstrap mode: needs a column()!
        )
    })
    

    
}

# Run the app ----
shinyApp(ui = ui, server = server)