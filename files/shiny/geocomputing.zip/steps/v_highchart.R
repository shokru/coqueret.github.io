library(tidyverse)
library(shiny)
library(shinydashboard)
library(DT)
library(sf)  
library(highcharter)
library(tmap)

hc_data <- get_data_from_map(download_map_data("custom/world")) # Column 11 is the one !!!
colnames(hc_data)[11] <- "Country"
load("olympics.RData")


ui <- dashboardPage(
    dashboardHeader(title = "Olympic Medals"),                   # Title of the dashboard
    dashboardSidebar( 
        sliderInput("years", h4("Years"),                        # Element 1: year selection
                    min = 1895, max = 2015, 
                    value = c(1895, 2015), step = 5, sep = ""),
        checkboxGroupInput("season", h4("Season"),               # Element 2: season selection
                           choices = list("Summer" = "Summer", 
                                          "Winter" = "Winter"),
                           selected = c("Summer", "Winter")),
        checkboxGroupInput("gender", h4("Gender"),               # Element 3: gender selection
                           choices = list("Women" = "Women", 
                                          "Men" = "Men"),
                           selected = c("Women", "Men"))
    ),
    
    dashboardBody(
        highchartOutput("plot", height = 500),
        DT::dataTableOutput("table_1")
    )
)

server <- function(input, output){
    data <- reactive({                # Creates the dynamic data
        olympics %>%                  # Filter years, seasons & gender
            filter(Year >= input$years[1], 
                   Year <= input$years[2],
                   Season %in% input$season,
                   Gender %in% input$gender) 
    })
    
    output$table_1 <- DT::renderDataTable({data()})
    
    ####### NEW ELEMENTS BELOW !!!!! The joining process is reverse compared to the leaflet example
    output$plot <- renderHighchart({
        data_map <- data() %>%
            group_by(Country) %>%
            summarize(value = n())                                          # Counts nb instances, like n()
        data_map <- hc_data %>%
            left_join(data_map %>% select(Country, value)) %>%              # Joining the n (counting) column
            na.omit()
        
        hcmap("custom/world",                                             # Source for the map
              data = data_map,                                            # Source for the color code
              value = "value",                                            # Column for color code
              joinBy = c("name"),                                         # Common name & label (keep it like that)
              name = "Medals per country",                                # Name of plot
              dataLabels = list(enabled = TRUE, format = "{point.name}"), # Allow labels
              borderColor = "#FAFAFA", borderWidth = 0.5,                 # Border info
              tooltip = list(valueDecimals = 0,                           # Label info
                             valuePrefix = "Value = ",                    # Before label
                             valueSuffix = " Medals"))                     # After label
    })
    
    
}

# Run the app ----
shinyApp(ui = ui, server = server)