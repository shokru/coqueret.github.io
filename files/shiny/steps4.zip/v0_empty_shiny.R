# Install packages
# install.packages("htmltools")
# install.packages("DT")
# install.packages("shiny")
# install.packages("shinydashboard")

library(DT)
library(shiny)
library(shinydashboard)

load("olympics.RData")

ui <- fluidPage(           # FULL PAGE: don't touch!
    
)  

server <- function(input, output){  # Server: computations!
    
}

# Run the app ----
shinyApp(ui = ui, server = server)  # Aggregates the app.