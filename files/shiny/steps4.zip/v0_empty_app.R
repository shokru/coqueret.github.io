# Install packages
install.packages("htmltools")
install.packages("DT")
install.packages("shiny")
install.packages("shinydashboard")


library(DT)
library(shiny)
library(shinydashboard)

load("olympics.RData")

ui <- dashboardPage(           # FULL PAGE: don't touch!
    dashboardHeader(),         # Header zone
    dashboardSidebar(),        # Sidebar zone
    dashboardBody()            # Body zone
)  

server <- function(input, output){  # Server: computations!
    
}

# Run the app ----
shinyApp(ui = ui, server = server)  # Aggregates the app.