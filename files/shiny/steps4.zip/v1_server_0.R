library(tidyverse)
library(shiny)
library(shinydashboard)

load("olympics.RData")

ui <- dashboardPage(
    dashboardHeader(title = "Olympic Medals"),                   # Title of the dashboard
    dashboardSidebar( 
        sliderInput("years", h4("Years"),                        # Element 1: year selection
                    min = 1895, max = 2015, 
                    value = c(1895, 2015), step = 5, sep = ""),
        checkboxGroupInput("season", h4("Season"),               # Element 2: season selection
                           choices = levels(olympics$Season),
                           selected = c("Summer", "Winter"))
    ),
    
    ####### NEW ELEMENTS BELOW !!!!!
    dashboardBody(
        h1(textOutput("example"))
    )
)

server <- function(input, output){
    ####### NEW ELEMENTS BELOW !!!!!
    output$example <- renderText("LOL") # Create the output object!
    
}

# Run the app ----
shinyApp(ui = ui, server = server)