if(!require(shiny)){install.packages(c("shiny", "shinydashboard", "DT"))}
library(tidyverse)
library(shiny)
library(shinydashboard)

load("olympics.RData")

ui <- dashboardPage(    # FULL PAGE: don't touch!
    ####### NEW ELEMENTS BELOW !!!!!
    dashboardHeader(title = "Olympic Medals"),                   # Title of the dashboard
    
    dashboardSidebar(                                            # Below, h2, h3, h4 refer to font sizes
      tags$style(type = "text/css", 
                 ".irs-grid-text:nth-child(1n) {color: white}",
                 ".irs-grid-pol:nth-child(1n) {background:white}"),
        sliderInput("years", h4("Years"),                        # Element 1: year selection
                    min = 1950, max = 2015,                      
                    value = c(1950, 2015), step = 5, sep = ""
                    ),                                           # Mind the comma! Separation with next widget
        checkboxGroupInput("season", h4("Season"),               # Element 2: season selection
                           choices = list("Summer" = "Summer",   # MANUAL filling!
                                          "Winter" = "Winter"),
                           selected = c("Summer", "Winter")
                           )
        ),
    dashboardBody(   # Empty

    )
)

server <- function(input, output){ # Empty
  
}

# Run the app ----
shinyApp(ui = ui, server = server)