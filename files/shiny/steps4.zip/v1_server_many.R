library(tidyverse)
library(shiny)
library(shinydashboard)
library(DT)

load("olympics.RData")

ui <- dashboardPage(
    dashboardHeader(title = "Olympic Medals"),                   # Title of the dashboard
    dashboardSidebar( 
        sliderInput("years", h4("Years"),                        # Element 1: year selection
                    min = 1895, max = 2015, 
                    value = c(1895, 2015), step = 5, sep = ""),
        checkboxGroupInput("season", h4("Season"),               # Element 2: season selection
                           choices = list("Summer" = "Summer", 
                                          "Winter" = "Winter"),
                           selected = c("Summer", "Winter")),
        checkboxGroupInput("gender", h4("Gender"),               # Element 3: gender selection
                           choices = list("Women" = "Women", 
                                          "Men" = "Men"),
                           selected = c("Women", "Men")),
        numericInput("max_nb", h4("Max number countries"),       # Element 4: nb of countries displayed
                     min = 2, max = 15, step = 1, value = 6),
        selectInput("country", h4("Country"),
                    choices = olympics$Country %>% unique() %>% sort(),
                    selected = "FRA", multiple = TRUE)
        ),
    
    ####### NEW ELEMENTS BELOW !!!!!
    dashboardBody(
        DT::dataTableOutput("pt")
    )
)

server <- function(input, output){
    ####### NEW ELEMENTS BELOW !!!!!
    data <- reactive({                # Creates the dynamic data
        olympics %>%      # Filter years, seasons & gender
            filter(Year >= input$years[1], 
                   Year <= input$years[2],
                   Season %in% input$season,
                   Gender %in% input$gender) 
    })
    
    output$pt <- DT::renderDataTable(data(), rownames = FALSE)
    
}

# Run the app ----
shinyApp(ui = ui, server = server)