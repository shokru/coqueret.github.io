library(tidyverse)
library(shiny)
library(shinydashboard)

load("olympics.RData")

ui <- dashboardPage(
    dashboardHeader(title = "Olympic Medals"),                   # Title of the dashboard
    dashboardSidebar(                                            # Below, h2, h3, h4 refer to font sizes
        sliderInput("years", h4("Years"),                        # Element 1: year selection
                    min = 1950, max = 2015,                      
                    value = c(1950, 2015), step = 5, sep = ""),  # Mind the comma! Separation with next widget
        checkboxGroupInput("season", h4("Season"),               # Element 2: season selection
                           choices = levels(olympics$Season),
                           selected = c("Summer", "Winter")),    # Comma!
        
        ####### NEW ELEMENTS BELOW !!!!!
        
        checkboxGroupInput("gender", h4("Gender"),               # Element 3: gender selection
                           choices = list("Women" = "Women", 
                                          "Men" = "Men"),
                           selected = c("Women", "Men")),        # Comma!
        numericInput("max_country", h4("Max number countries"),  # Element 4: nb of countries displayed
                     min = 2, max = 12, step = 1, value = 6)
        ),
    dashboardBody(   # Empty

    )
)

server <- function(input, output){ # Empty
  
}

# Run the app ----
shinyApp(ui = ui, server = server)